﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace eSDK_UC_ConfMgrDemo_Windows_CSharp
{
    public class QueryConfList
    {
        public string userId { get; set; }
        public string confId { get; set; }
        public string phone { get; set; }
        public string confName { get; set; }
        public string startTime { get; set; }
        public string endTime { get; set; }
        public string pageNum { get; set; }
        public string pageCount { get; set; }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace eSDK_UC_ConfMgrDemo_Windows_CSharp
{
    public class AddConfInfo
    {
        public string userId { get; set; }
        public string gwIp { get; set; }
        public string subPbx { get; set; }
        public string enterPrompt { get; set; }
        public string leavePrompt { get; set; }
        public string amount { get; set; }
        public string guestPwd { get; set; }
        public string chairmanPwd { get; set; }
        public string startTime { get; set; }
        public string endTime { get; set; }
        public string confMode { get; set; }
        public string recordFlag { get; set; }
        public string confName { get; set; }
        public string srtpMode { get; set; }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace eSDK_UC_AccountMgrDemo_Windows_CSharp
{
    public class DepartmentResponse
    {
        public string resultCode { get; set; }

        public string resultContext { get; set; }

        public string departmentId { get; set; }

        public string departmentNo { get; set; }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace eSDK_UC_AccountMgrDemo_Windows_CSharp
{
    public class AddAcountResponse
    {
        public string resultCode { get; set; }

        public string resultContext { get; set; }
        //账号ID
        public string result { get; set; }
    }
}

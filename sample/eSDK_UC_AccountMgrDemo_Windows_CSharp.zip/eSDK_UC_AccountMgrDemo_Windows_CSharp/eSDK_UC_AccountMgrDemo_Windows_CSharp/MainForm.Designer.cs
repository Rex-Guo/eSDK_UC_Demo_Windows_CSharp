﻿namespace eSDK_UC_AccountMgrDemo_Windows_CSharp
{
    partial class MainForm
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.txt_pw5 = new System.Windows.Forms.TextBox();
            this.txt_UserName = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txt_Uri = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btn_queryDepartment = new System.Windows.Forms.Button();
            this.btn_delDepartment = new System.Windows.Forms.Button();
            this.btn_editDepartment = new System.Windows.Forms.Button();
            this.btn_addDepartment = new System.Windows.Forms.Button();
            this.txt_dpPageNum = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.txt_dpPageCount = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.txt_departmentId = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txt_parentId = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txt_departmentName = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txt_Account = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.cbx_IsExact = new System.Windows.Forms.ComboBox();
            this.label26 = new System.Windows.Forms.Label();
            this.cbx_accountType = new System.Windows.Forms.ComboBox();
            this.label25 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.txt_codition = new System.Windows.Forms.TextBox();
            this.label23 = new System.Windows.Forms.Label();
            this.txt_accountpageCount = new System.Windows.Forms.TextBox();
            this.label24 = new System.Windows.Forms.Label();
            this.txt_accountPageNum = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.txt_accountIdEx = new System.Windows.Forms.TextBox();
            this.btn_QueryAccount = new System.Windows.Forms.Button();
            this.btn_delAccount = new System.Windows.Forms.Button();
            this.btn_editAccount = new System.Windows.Forms.Button();
            this.btn_AddAccount = new System.Windows.Forms.Button();
            this.cbx_accountState = new System.Windows.Forms.ComboBox();
            this.label20 = new System.Windows.Forms.Label();
            this.txt_dpId = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.txt_roleId = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.txt_levelId = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.txt_accountName = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.txt_loginPw5 = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.txt_loginName = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.txt_AccountId = new System.Windows.Forms.TextBox();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.cbx_deleteSipUe = new System.Windows.Forms.ComboBox();
            this.label37 = new System.Windows.Forms.Label();
            this.cbx_authType = new System.Windows.Forms.ComboBox();
            this.label33 = new System.Windows.Forms.Label();
            this.cbx_addPrefix = new System.Windows.Forms.ComboBox();
            this.label36 = new System.Windows.Forms.Label();
            this.cbx_rightLevel = new System.Windows.Forms.ComboBox();
            this.label32 = new System.Windows.Forms.Label();
            this.cbx_deviceType = new System.Windows.Forms.ComboBox();
            this.label41 = new System.Windows.Forms.Label();
            this.cbx_isExactQuery = new System.Windows.Forms.ComboBox();
            this.label27 = new System.Windows.Forms.Label();
            this.cbx_isJoint = new System.Windows.Forms.ComboBox();
            this.label28 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.txt_queryConditionValue = new System.Windows.Forms.TextBox();
            this.label30 = new System.Windows.Forms.Label();
            this.txt_sipPageNum = new System.Windows.Forms.TextBox();
            this.label31 = new System.Windows.Forms.Label();
            this.txt_sipPageCount = new System.Windows.Forms.TextBox();
            this.btn_querySipNumber = new System.Windows.Forms.Button();
            this.btn_delSipNumber = new System.Windows.Forms.Button();
            this.btn_editSipNumber = new System.Windows.Forms.Button();
            this.btn_addSipNumber = new System.Windows.Forms.Button();
            this.label34 = new System.Windows.Forms.Label();
            this.txt_authIp = new System.Windows.Forms.TextBox();
            this.label35 = new System.Windows.Forms.Label();
            this.txt_authPw5 = new System.Windows.Forms.TextBox();
            this.label38 = new System.Windows.Forms.Label();
            this.txt_SipNumber = new System.Windows.Forms.TextBox();
            this.label39 = new System.Windows.Forms.Label();
            this.txt_gwIp = new System.Windows.Forms.TextBox();
            this.label40 = new System.Windows.Forms.Label();
            this.txt_sipUser = new System.Windows.Forms.TextBox();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.txt_Content = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.txt_ResultInfo = new System.Windows.Forms.RichTextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.txt_ResultCode = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.txt_log = new System.Windows.Forms.RichTextBox();
            this.txt_userAccount = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.cbx_queryConditionType = new System.Windows.Forms.ComboBox();
            this.label42 = new System.Windows.Forms.Label();
            this.btn_queryEmployee = new System.Windows.Forms.Button();
            this.btn_queryEnterprise = new System.Windows.Forms.Button();
            this.btn_QueryPersonInfo = new System.Windows.Forms.Button();
            this.btn_QueryAddress = new System.Windows.Forms.Button();
            this.label43 = new System.Windows.Forms.Label();
            this.txt_ECAccount = new System.Windows.Forms.TextBox();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.label44 = new System.Windows.Forms.Label();
            this.txt_queryCondition = new System.Windows.Forms.TextBox();
            this.label45 = new System.Windows.Forms.Label();
            this.txt_pageNum = new System.Windows.Forms.TextBox();
            this.label46 = new System.Windows.Forms.Label();
            this.txt_pageCount = new System.Windows.Forms.TextBox();
            this.label47 = new System.Windows.Forms.Label();
            this.txt_beECAccount = new System.Windows.Forms.TextBox();
            this.label48 = new System.Windows.Forms.Label();
            this.txt_departmentIDEx = new System.Windows.Forms.TextBox();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.tabPage4.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.SuspendLayout();
            // 
            // txt_pw5
            // 
            this.txt_pw5.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txt_pw5.Location = new System.Drawing.Point(269, 41);
            this.txt_pw5.Name = "txt_pw5";
            this.txt_pw5.Size = new System.Drawing.Size(135, 21);
            this.txt_pw5.TabIndex = 12;
            this.txt_pw5.Text = "Huawei@123";
            this.txt_pw5.UseSystemPasswordChar = true;
            this.txt_pw5.TextChanged += new System.EventHandler(this.txtConfig_TextChanged);
            // 
            // txt_UserName
            // 
            this.txt_UserName.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txt_UserName.Location = new System.Drawing.Point(86, 41);
            this.txt_UserName.Name = "txt_UserName";
            this.txt_UserName.Size = new System.Drawing.Size(117, 21);
            this.txt_UserName.TabIndex = 11;
            this.txt_UserName.Text = "esdk_user";
            this.txt_UserName.TextChanged += new System.EventHandler(this.txtConfig_TextChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label3.Location = new System.Drawing.Point(222, 45);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(44, 12);
            this.label3.TabIndex = 10;
            this.label3.Text = "密码：";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label2.Location = new System.Drawing.Point(14, 46);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(57, 12);
            this.label2.TabIndex = 9;
            this.label2.Text = "用户名：";
            // 
            // txt_Uri
            // 
            this.txt_Uri.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txt_Uri.Location = new System.Drawing.Point(86, 5);
            this.txt_Uri.Name = "txt_Uri";
            this.txt_Uri.Size = new System.Drawing.Size(320, 21);
            this.txt_Uri.TabIndex = 8;
            this.txt_Uri.Text = "http://172.22.9.42:8086";
            this.txt_Uri.TextChanged += new System.EventHandler(this.txtConfig_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(68, 12);
            this.label1.TabIndex = 7;
            this.label1.Text = "eSDK URI:";
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Location = new System.Drawing.Point(3, 72);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(467, 402);
            this.tabControl1.TabIndex = 13;
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.tabPage1.Controls.Add(this.groupBox1);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(459, 376);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "部门管理";
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.groupBox1.Controls.Add(this.btn_queryDepartment);
            this.groupBox1.Controls.Add(this.btn_delDepartment);
            this.groupBox1.Controls.Add(this.btn_editDepartment);
            this.groupBox1.Controls.Add(this.btn_addDepartment);
            this.groupBox1.Controls.Add(this.txt_dpPageNum);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.txt_dpPageCount);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.txt_departmentId);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.txt_parentId);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.txt_departmentName);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.txt_Account);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Location = new System.Drawing.Point(5, 6);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(448, 362);
            this.groupBox1.TabIndex = 8;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "输入参数";
            // 
            // btn_queryDepartment
            // 
            this.btn_queryDepartment.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btn_queryDepartment.Location = new System.Drawing.Point(245, 288);
            this.btn_queryDepartment.Name = "btn_queryDepartment";
            this.btn_queryDepartment.Size = new System.Drawing.Size(112, 43);
            this.btn_queryDepartment.TabIndex = 21;
            this.btn_queryDepartment.Text = "查询部门";
            this.btn_queryDepartment.UseVisualStyleBackColor = true;
            this.btn_queryDepartment.Click += new System.EventHandler(this.btn_queryDepartment_Click);
            // 
            // btn_delDepartment
            // 
            this.btn_delDepartment.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btn_delDepartment.Location = new System.Drawing.Point(78, 288);
            this.btn_delDepartment.Name = "btn_delDepartment";
            this.btn_delDepartment.Size = new System.Drawing.Size(112, 43);
            this.btn_delDepartment.TabIndex = 20;
            this.btn_delDepartment.Text = "删除部门";
            this.btn_delDepartment.UseVisualStyleBackColor = true;
            this.btn_delDepartment.Click += new System.EventHandler(this.btn_delDepartment_Click);
            // 
            // btn_editDepartment
            // 
            this.btn_editDepartment.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btn_editDepartment.Location = new System.Drawing.Point(245, 209);
            this.btn_editDepartment.Name = "btn_editDepartment";
            this.btn_editDepartment.Size = new System.Drawing.Size(112, 43);
            this.btn_editDepartment.TabIndex = 19;
            this.btn_editDepartment.Text = "修改部门";
            this.btn_editDepartment.UseVisualStyleBackColor = true;
            this.btn_editDepartment.Click += new System.EventHandler(this.btn_editDepartment_Click);
            // 
            // btn_addDepartment
            // 
            this.btn_addDepartment.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btn_addDepartment.Location = new System.Drawing.Point(78, 209);
            this.btn_addDepartment.Name = "btn_addDepartment";
            this.btn_addDepartment.Size = new System.Drawing.Size(112, 43);
            this.btn_addDepartment.TabIndex = 18;
            this.btn_addDepartment.Text = "添加部门";
            this.btn_addDepartment.UseVisualStyleBackColor = true;
            this.btn_addDepartment.Click += new System.EventHandler(this.btn_addDepartment_Click);
            // 
            // txt_dpPageNum
            // 
            this.txt_dpPageNum.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txt_dpPageNum.Location = new System.Drawing.Point(304, 138);
            this.txt_dpPageNum.Name = "txt_dpPageNum";
            this.txt_dpPageNum.Size = new System.Drawing.Size(103, 23);
            this.txt_dpPageNum.TabIndex = 17;
            this.txt_dpPageNum.Text = "1";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label8.Location = new System.Drawing.Point(229, 143);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(77, 14);
            this.label8.TabIndex = 16;
            this.label8.Text = "当前页数：";
            // 
            // txt_dpPageCount
            // 
            this.txt_dpPageCount.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txt_dpPageCount.Location = new System.Drawing.Point(129, 138);
            this.txt_dpPageCount.Name = "txt_dpPageCount";
            this.txt_dpPageCount.Size = new System.Drawing.Size(85, 23);
            this.txt_dpPageCount.TabIndex = 15;
            this.txt_dpPageCount.Text = "10";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label9.Location = new System.Drawing.Point(38, 143);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(91, 14);
            this.label9.TabIndex = 14;
            this.label9.Text = "每页显示数：";
            // 
            // txt_departmentId
            // 
            this.txt_departmentId.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txt_departmentId.Location = new System.Drawing.Point(304, 86);
            this.txt_departmentId.Name = "txt_departmentId";
            this.txt_departmentId.Size = new System.Drawing.Size(103, 23);
            this.txt_departmentId.TabIndex = 13;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label6.Location = new System.Drawing.Point(229, 91);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(63, 14);
            this.label6.TabIndex = 12;
            this.label6.Text = "部门ID：";
            // 
            // txt_parentId
            // 
            this.txt_parentId.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txt_parentId.Location = new System.Drawing.Point(127, 88);
            this.txt_parentId.Name = "txt_parentId";
            this.txt_parentId.Size = new System.Drawing.Size(85, 23);
            this.txt_parentId.TabIndex = 11;
            this.txt_parentId.Text = "1";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label7.Location = new System.Drawing.Point(38, 95);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(77, 14);
            this.label7.TabIndex = 10;
            this.label7.Text = "父部门ID：";
            // 
            // txt_departmentName
            // 
            this.txt_departmentName.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txt_departmentName.Location = new System.Drawing.Point(304, 38);
            this.txt_departmentName.Name = "txt_departmentName";
            this.txt_departmentName.Size = new System.Drawing.Size(103, 23);
            this.txt_departmentName.TabIndex = 9;
            this.txt_departmentName.Text = "test123456";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label5.Location = new System.Drawing.Point(229, 43);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(77, 14);
            this.label5.TabIndex = 8;
            this.label5.Text = "部门名称：";
            // 
            // txt_Account
            // 
            this.txt_Account.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txt_Account.Location = new System.Drawing.Point(129, 36);
            this.txt_Account.Name = "txt_Account";
            this.txt_Account.Size = new System.Drawing.Size(85, 23);
            this.txt_Account.TabIndex = 7;
            this.txt_Account.Text = "12345";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label4.Location = new System.Drawing.Point(38, 41);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(77, 14);
            this.label4.TabIndex = 6;
            this.label4.Text = "操作者ID：";
            // 
            // tabPage2
            // 
            this.tabPage2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.tabPage2.Controls.Add(this.groupBox3);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(459, 376);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "账号管理";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.cbx_IsExact);
            this.groupBox3.Controls.Add(this.label26);
            this.groupBox3.Controls.Add(this.cbx_accountType);
            this.groupBox3.Controls.Add(this.label25);
            this.groupBox3.Controls.Add(this.label22);
            this.groupBox3.Controls.Add(this.txt_codition);
            this.groupBox3.Controls.Add(this.label23);
            this.groupBox3.Controls.Add(this.txt_accountpageCount);
            this.groupBox3.Controls.Add(this.label24);
            this.groupBox3.Controls.Add(this.txt_accountPageNum);
            this.groupBox3.Controls.Add(this.label21);
            this.groupBox3.Controls.Add(this.txt_accountIdEx);
            this.groupBox3.Controls.Add(this.btn_QueryAccount);
            this.groupBox3.Controls.Add(this.btn_delAccount);
            this.groupBox3.Controls.Add(this.btn_editAccount);
            this.groupBox3.Controls.Add(this.btn_AddAccount);
            this.groupBox3.Controls.Add(this.cbx_accountState);
            this.groupBox3.Controls.Add(this.label20);
            this.groupBox3.Controls.Add(this.txt_dpId);
            this.groupBox3.Controls.Add(this.label19);
            this.groupBox3.Controls.Add(this.txt_roleId);
            this.groupBox3.Controls.Add(this.label18);
            this.groupBox3.Controls.Add(this.txt_levelId);
            this.groupBox3.Controls.Add(this.label17);
            this.groupBox3.Controls.Add(this.label16);
            this.groupBox3.Controls.Add(this.txt_accountName);
            this.groupBox3.Controls.Add(this.label15);
            this.groupBox3.Controls.Add(this.txt_loginPw5);
            this.groupBox3.Controls.Add(this.label14);
            this.groupBox3.Controls.Add(this.txt_loginName);
            this.groupBox3.Controls.Add(this.label13);
            this.groupBox3.Controls.Add(this.txt_AccountId);
            this.groupBox3.Location = new System.Drawing.Point(6, 6);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(447, 362);
            this.groupBox3.TabIndex = 2;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "输入参数";
            // 
            // cbx_IsExact
            // 
            this.cbx_IsExact.FormattingEnabled = true;
            this.cbx_IsExact.Items.AddRange(new object[] {
            "0",
            "1"});
            this.cbx_IsExact.Location = new System.Drawing.Point(259, 220);
            this.cbx_IsExact.Name = "cbx_IsExact";
            this.cbx_IsExact.Size = new System.Drawing.Size(80, 20);
            this.cbx_IsExact.TabIndex = 37;
            this.cbx_IsExact.Text = "0";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(192, 226);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(65, 12);
            this.label26.TabIndex = 36;
            this.label26.Text = "精确查找：";
            // 
            // cbx_accountType
            // 
            this.cbx_accountType.FormattingEnabled = true;
            this.cbx_accountType.Items.AddRange(new object[] {
            "0",
            "2"});
            this.cbx_accountType.Location = new System.Drawing.Point(221, 16);
            this.cbx_accountType.Name = "cbx_accountType";
            this.cbx_accountType.Size = new System.Drawing.Size(80, 20);
            this.cbx_accountType.TabIndex = 35;
            this.cbx_accountType.Text = "0";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(158, 21);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(65, 12);
            this.label25.TabIndex = 34;
            this.label25.Text = "用户类型：";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(6, 223);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(65, 12);
            this.label22.TabIndex = 32;
            this.label22.Text = "查询条件：";
            // 
            // txt_codition
            // 
            this.txt_codition.Location = new System.Drawing.Point(88, 220);
            this.txt_codition.Name = "txt_codition";
            this.txt_codition.Size = new System.Drawing.Size(80, 21);
            this.txt_codition.TabIndex = 33;
            this.txt_codition.Text = "test";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(188, 261);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(65, 12);
            this.label23.TabIndex = 30;
            this.label23.Text = "当前页数：";
            // 
            // txt_accountpageCount
            // 
            this.txt_accountpageCount.Location = new System.Drawing.Point(259, 258);
            this.txt_accountpageCount.Name = "txt_accountpageCount";
            this.txt_accountpageCount.Size = new System.Drawing.Size(80, 21);
            this.txt_accountpageCount.TabIndex = 31;
            this.txt_accountpageCount.Text = "1";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(5, 261);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(77, 12);
            this.label24.TabIndex = 28;
            this.label24.Text = "每页显示数：";
            // 
            // txt_accountPageNum
            // 
            this.txt_accountPageNum.Location = new System.Drawing.Point(88, 258);
            this.txt_accountPageNum.Name = "txt_accountPageNum";
            this.txt_accountPageNum.Size = new System.Drawing.Size(80, 21);
            this.txt_accountPageNum.TabIndex = 29;
            this.txt_accountPageNum.Text = "5";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(307, 82);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(53, 12);
            this.label21.TabIndex = 26;
            this.label21.Text = "用户ID：";
            // 
            // txt_accountIdEx
            // 
            this.txt_accountIdEx.Location = new System.Drawing.Point(361, 76);
            this.txt_accountIdEx.Name = "txt_accountIdEx";
            this.txt_accountIdEx.Size = new System.Drawing.Size(80, 21);
            this.txt_accountIdEx.TabIndex = 27;
            // 
            // btn_QueryAccount
            // 
            this.btn_QueryAccount.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btn_QueryAccount.Location = new System.Drawing.Point(171, 304);
            this.btn_QueryAccount.Name = "btn_QueryAccount";
            this.btn_QueryAccount.Size = new System.Drawing.Size(112, 43);
            this.btn_QueryAccount.TabIndex = 25;
            this.btn_QueryAccount.Text = "查询账户";
            this.btn_QueryAccount.UseVisualStyleBackColor = true;
            this.btn_QueryAccount.Click += new System.EventHandler(this.btn_QueryAccount_Click);
            // 
            // btn_delAccount
            // 
            this.btn_delAccount.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btn_delAccount.Location = new System.Drawing.Point(329, 155);
            this.btn_delAccount.Name = "btn_delAccount";
            this.btn_delAccount.Size = new System.Drawing.Size(112, 43);
            this.btn_delAccount.TabIndex = 24;
            this.btn_delAccount.Text = "删除账户";
            this.btn_delAccount.UseVisualStyleBackColor = true;
            this.btn_delAccount.Click += new System.EventHandler(this.btn_delAccount_Click);
            // 
            // btn_editAccount
            // 
            this.btn_editAccount.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btn_editAccount.Location = new System.Drawing.Point(171, 155);
            this.btn_editAccount.Name = "btn_editAccount";
            this.btn_editAccount.Size = new System.Drawing.Size(112, 43);
            this.btn_editAccount.TabIndex = 23;
            this.btn_editAccount.Text = "修改账户";
            this.btn_editAccount.UseVisualStyleBackColor = true;
            this.btn_editAccount.Click += new System.EventHandler(this.btn_editAccount_Click);
            // 
            // btn_AddAccount
            // 
            this.btn_AddAccount.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btn_AddAccount.Location = new System.Drawing.Point(8, 155);
            this.btn_AddAccount.Name = "btn_AddAccount";
            this.btn_AddAccount.Size = new System.Drawing.Size(112, 43);
            this.btn_AddAccount.TabIndex = 22;
            this.btn_AddAccount.Text = "添加账户";
            this.btn_AddAccount.UseVisualStyleBackColor = true;
            this.btn_AddAccount.Click += new System.EventHandler(this.btn_AddAccount_Click);
            // 
            // cbx_accountState
            // 
            this.cbx_accountState.FormattingEnabled = true;
            this.cbx_accountState.Items.AddRange(new object[] {
            "0",
            "4"});
            this.cbx_accountState.Location = new System.Drawing.Point(221, 79);
            this.cbx_accountState.Name = "cbx_accountState";
            this.cbx_accountState.Size = new System.Drawing.Size(80, 20);
            this.cbx_accountState.TabIndex = 16;
            this.cbx_accountState.Text = "0";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(6, 117);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(53, 12);
            this.label20.TabIndex = 14;
            this.label20.Text = "部门ID：";
            // 
            // txt_dpId
            // 
            this.txt_dpId.Location = new System.Drawing.Point(72, 111);
            this.txt_dpId.Name = "txt_dpId";
            this.txt_dpId.Size = new System.Drawing.Size(80, 21);
            this.txt_dpId.TabIndex = 15;
            this.txt_dpId.Text = "1";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(309, 117);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(53, 12);
            this.label19.TabIndex = 12;
            this.label19.Text = "角色ID：";
            // 
            // txt_roleId
            // 
            this.txt_roleId.Location = new System.Drawing.Point(363, 111);
            this.txt_roleId.Name = "txt_roleId";
            this.txt_roleId.Size = new System.Drawing.Size(80, 21);
            this.txt_roleId.TabIndex = 13;
            this.txt_roleId.Text = "1";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(158, 117);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(53, 12);
            this.label18.TabIndex = 10;
            this.label18.Text = "级别ID：";
            // 
            // txt_levelId
            // 
            this.txt_levelId.Location = new System.Drawing.Point(222, 111);
            this.txt_levelId.Name = "txt_levelId";
            this.txt_levelId.Size = new System.Drawing.Size(80, 21);
            this.txt_levelId.TabIndex = 11;
            this.txt_levelId.Text = "1";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(157, 85);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(65, 12);
            this.label17.TabIndex = 8;
            this.label17.Text = "用户状态：";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(6, 85);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(65, 12);
            this.label16.TabIndex = 6;
            this.label16.Text = "用户名称：";
            // 
            // txt_accountName
            // 
            this.txt_accountName.Location = new System.Drawing.Point(70, 79);
            this.txt_accountName.Name = "txt_accountName";
            this.txt_accountName.Size = new System.Drawing.Size(80, 21);
            this.txt_accountName.TabIndex = 7;
            this.txt_accountName.Text = "glf";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(157, 52);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(65, 12);
            this.label15.TabIndex = 4;
            this.label15.Text = "登入密码：";
            // 
            // txt_loginPw5
            // 
            this.txt_loginPw5.Location = new System.Drawing.Point(221, 45);
            this.txt_loginPw5.Name = "txt_loginPw5";
            this.txt_loginPw5.Size = new System.Drawing.Size(78, 21);
            this.txt_loginPw5.TabIndex = 5;
            this.txt_loginPw5.Text = "Huawei@123";
            this.txt_loginPw5.UseSystemPasswordChar = true;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(6, 54);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(65, 12);
            this.label14.TabIndex = 2;
            this.label14.Text = "登入名称：";
            // 
            // txt_loginName
            // 
            this.txt_loginName.Location = new System.Drawing.Point(70, 48);
            this.txt_loginName.Name = "txt_loginName";
            this.txt_loginName.Size = new System.Drawing.Size(80, 21);
            this.txt_loginName.TabIndex = 3;
            this.txt_loginName.Text = "glf";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(6, 24);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(65, 12);
            this.label13.TabIndex = 0;
            this.label13.Text = "操作者ID：";
            // 
            // txt_AccountId
            // 
            this.txt_AccountId.Location = new System.Drawing.Point(70, 18);
            this.txt_AccountId.Name = "txt_AccountId";
            this.txt_AccountId.Size = new System.Drawing.Size(80, 21);
            this.txt_AccountId.TabIndex = 1;
            this.txt_AccountId.Text = "12345";
            // 
            // tabPage3
            // 
            this.tabPage3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.tabPage3.Controls.Add(this.groupBox4);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Size = new System.Drawing.Size(459, 376);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "SIP号码管理";
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.label42);
            this.groupBox4.Controls.Add(this.cbx_queryConditionType);
            this.groupBox4.Controls.Add(this.cbx_deleteSipUe);
            this.groupBox4.Controls.Add(this.label37);
            this.groupBox4.Controls.Add(this.cbx_authType);
            this.groupBox4.Controls.Add(this.label33);
            this.groupBox4.Controls.Add(this.cbx_addPrefix);
            this.groupBox4.Controls.Add(this.label36);
            this.groupBox4.Controls.Add(this.cbx_rightLevel);
            this.groupBox4.Controls.Add(this.label32);
            this.groupBox4.Controls.Add(this.cbx_deviceType);
            this.groupBox4.Controls.Add(this.label41);
            this.groupBox4.Controls.Add(this.cbx_isExactQuery);
            this.groupBox4.Controls.Add(this.label27);
            this.groupBox4.Controls.Add(this.cbx_isJoint);
            this.groupBox4.Controls.Add(this.label28);
            this.groupBox4.Controls.Add(this.label29);
            this.groupBox4.Controls.Add(this.txt_queryConditionValue);
            this.groupBox4.Controls.Add(this.label30);
            this.groupBox4.Controls.Add(this.txt_sipPageNum);
            this.groupBox4.Controls.Add(this.label31);
            this.groupBox4.Controls.Add(this.txt_sipPageCount);
            this.groupBox4.Controls.Add(this.btn_querySipNumber);
            this.groupBox4.Controls.Add(this.btn_delSipNumber);
            this.groupBox4.Controls.Add(this.btn_editSipNumber);
            this.groupBox4.Controls.Add(this.btn_addSipNumber);
            this.groupBox4.Controls.Add(this.label34);
            this.groupBox4.Controls.Add(this.txt_authIp);
            this.groupBox4.Controls.Add(this.label35);
            this.groupBox4.Controls.Add(this.txt_authPw5);
            this.groupBox4.Controls.Add(this.label38);
            this.groupBox4.Controls.Add(this.txt_SipNumber);
            this.groupBox4.Controls.Add(this.label39);
            this.groupBox4.Controls.Add(this.txt_gwIp);
            this.groupBox4.Controls.Add(this.label40);
            this.groupBox4.Controls.Add(this.txt_sipUser);
            this.groupBox4.Location = new System.Drawing.Point(6, 6);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(447, 362);
            this.groupBox4.TabIndex = 3;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "输入参数";
            // 
            // cbx_deleteSipUe
            // 
            this.cbx_deleteSipUe.FormattingEnabled = true;
            this.cbx_deleteSipUe.Items.AddRange(new object[] {
            "0",
            "1"});
            this.cbx_deleteSipUe.Location = new System.Drawing.Point(392, 77);
            this.cbx_deleteSipUe.Name = "cbx_deleteSipUe";
            this.cbx_deleteSipUe.Size = new System.Drawing.Size(46, 20);
            this.cbx_deleteSipUe.TabIndex = 47;
            this.cbx_deleteSipUe.Text = "0";
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Location = new System.Drawing.Point(274, 82);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(119, 12);
            this.label37.TabIndex = 46;
            this.label37.Text = "删除设备或SIP号码：";
            // 
            // cbx_authType
            // 
            this.cbx_authType.FormattingEnabled = true;
            this.cbx_authType.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3"});
            this.cbx_authType.Location = new System.Drawing.Point(72, 109);
            this.cbx_authType.Name = "cbx_authType";
            this.cbx_authType.Size = new System.Drawing.Size(78, 20);
            this.cbx_authType.TabIndex = 45;
            this.cbx_authType.Text = "0";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(8, 114);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(65, 12);
            this.label33.TabIndex = 44;
            this.label33.Text = "鉴权方式：";
            // 
            // cbx_addPrefix
            // 
            this.cbx_addPrefix.FormattingEnabled = true;
            this.cbx_addPrefix.Items.AddRange(new object[] {
            "0",
            "1"});
            this.cbx_addPrefix.Location = new System.Drawing.Point(358, 45);
            this.cbx_addPrefix.Name = "cbx_addPrefix";
            this.cbx_addPrefix.Size = new System.Drawing.Size(46, 20);
            this.cbx_addPrefix.TabIndex = 43;
            this.cbx_addPrefix.Text = "0";
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Location = new System.Drawing.Point(274, 52);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(89, 12);
            this.label36.TabIndex = 42;
            this.label36.Text = "自动添加字冠：";
            // 
            // cbx_rightLevel
            // 
            this.cbx_rightLevel.FormattingEnabled = true;
            this.cbx_rightLevel.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3"});
            this.cbx_rightLevel.Location = new System.Drawing.Point(222, 79);
            this.cbx_rightLevel.Name = "cbx_rightLevel";
            this.cbx_rightLevel.Size = new System.Drawing.Size(46, 20);
            this.cbx_rightLevel.TabIndex = 41;
            this.cbx_rightLevel.Text = "0";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(158, 84);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(65, 12);
            this.label32.TabIndex = 40;
            this.label32.Text = "权限级别：";
            // 
            // cbx_deviceType
            // 
            this.cbx_deviceType.FormattingEnabled = true;
            this.cbx_deviceType.Items.AddRange(new object[] {
            "0",
            "2"});
            this.cbx_deviceType.Location = new System.Drawing.Point(72, 77);
            this.cbx_deviceType.Name = "cbx_deviceType";
            this.cbx_deviceType.Size = new System.Drawing.Size(78, 20);
            this.cbx_deviceType.TabIndex = 39;
            this.cbx_deviceType.Text = "0";
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Location = new System.Drawing.Point(8, 82);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(65, 12);
            this.label41.TabIndex = 38;
            this.label41.Text = "设备类型：";
            // 
            // cbx_isExactQuery
            // 
            this.cbx_isExactQuery.FormattingEnabled = true;
            this.cbx_isExactQuery.Items.AddRange(new object[] {
            "0",
            "1"});
            this.cbx_isExactQuery.Location = new System.Drawing.Point(73, 261);
            this.cbx_isExactQuery.Name = "cbx_isExactQuery";
            this.cbx_isExactQuery.Size = new System.Drawing.Size(48, 20);
            this.cbx_isExactQuery.TabIndex = 37;
            this.cbx_isExactQuery.Text = "0";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(8, 265);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(65, 12);
            this.label27.TabIndex = 36;
            this.label27.Text = "精确查找：";
            // 
            // cbx_isJoint
            // 
            this.cbx_isJoint.FormattingEnabled = true;
            this.cbx_isJoint.Items.AddRange(new object[] {
            "0",
            "1"});
            this.cbx_isJoint.Location = new System.Drawing.Point(222, 47);
            this.cbx_isJoint.Name = "cbx_isJoint";
            this.cbx_isJoint.Size = new System.Drawing.Size(46, 20);
            this.cbx_isJoint.TabIndex = 35;
            this.cbx_isJoint.Text = "0";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(158, 21);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(77, 12);
            this.label28.TabIndex = 34;
            this.label28.Text = "统一网关IP：";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(6, 223);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(65, 12);
            this.label29.TabIndex = 32;
            this.label29.Text = "查询类型：";
            // 
            // txt_queryConditionValue
            // 
            this.txt_queryConditionValue.Location = new System.Drawing.Point(211, 219);
            this.txt_queryConditionValue.Name = "txt_queryConditionValue";
            this.txt_queryConditionValue.Size = new System.Drawing.Size(146, 21);
            this.txt_queryConditionValue.TabIndex = 33;
            this.txt_queryConditionValue.Text = "172.22.9.44";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(292, 265);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(65, 12);
            this.label30.TabIndex = 30;
            this.label30.Text = "当前页数：";
            // 
            // txt_sipPageNum
            // 
            this.txt_sipPageNum.Location = new System.Drawing.Point(363, 260);
            this.txt_sipPageNum.Name = "txt_sipPageNum";
            this.txt_sipPageNum.Size = new System.Drawing.Size(65, 21);
            this.txt_sipPageNum.TabIndex = 31;
            this.txt_sipPageNum.Text = "1";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(134, 265);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(77, 12);
            this.label31.TabIndex = 28;
            this.label31.Text = "每页显示数：";
            // 
            // txt_sipPageCount
            // 
            this.txt_sipPageCount.Location = new System.Drawing.Point(215, 260);
            this.txt_sipPageCount.Name = "txt_sipPageCount";
            this.txt_sipPageCount.Size = new System.Drawing.Size(62, 21);
            this.txt_sipPageCount.TabIndex = 29;
            this.txt_sipPageCount.Text = "5";
            // 
            // btn_querySipNumber
            // 
            this.btn_querySipNumber.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btn_querySipNumber.Location = new System.Drawing.Point(171, 304);
            this.btn_querySipNumber.Name = "btn_querySipNumber";
            this.btn_querySipNumber.Size = new System.Drawing.Size(112, 43);
            this.btn_querySipNumber.TabIndex = 25;
            this.btn_querySipNumber.Text = "查询SIP号码";
            this.btn_querySipNumber.UseVisualStyleBackColor = true;
            this.btn_querySipNumber.Click += new System.EventHandler(this.btn_querySipNumber_Click);
            // 
            // btn_delSipNumber
            // 
            this.btn_delSipNumber.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btn_delSipNumber.Location = new System.Drawing.Point(329, 155);
            this.btn_delSipNumber.Name = "btn_delSipNumber";
            this.btn_delSipNumber.Size = new System.Drawing.Size(112, 43);
            this.btn_delSipNumber.TabIndex = 24;
            this.btn_delSipNumber.Text = "删除SIP号码";
            this.btn_delSipNumber.UseVisualStyleBackColor = true;
            this.btn_delSipNumber.Click += new System.EventHandler(this.btn_delSipNumber_Click);
            // 
            // btn_editSipNumber
            // 
            this.btn_editSipNumber.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btn_editSipNumber.Location = new System.Drawing.Point(171, 155);
            this.btn_editSipNumber.Name = "btn_editSipNumber";
            this.btn_editSipNumber.Size = new System.Drawing.Size(112, 43);
            this.btn_editSipNumber.TabIndex = 23;
            this.btn_editSipNumber.Text = "修改SIP号码";
            this.btn_editSipNumber.UseVisualStyleBackColor = true;
            this.btn_editSipNumber.Click += new System.EventHandler(this.btn_editSipNumber_Click);
            // 
            // btn_addSipNumber
            // 
            this.btn_addSipNumber.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btn_addSipNumber.Location = new System.Drawing.Point(8, 155);
            this.btn_addSipNumber.Name = "btn_addSipNumber";
            this.btn_addSipNumber.Size = new System.Drawing.Size(112, 43);
            this.btn_addSipNumber.TabIndex = 22;
            this.btn_addSipNumber.Text = "添加SIP号码";
            this.btn_addSipNumber.UseVisualStyleBackColor = true;
            this.btn_addSipNumber.Click += new System.EventHandler(this.btn_addSipNumber_Click);
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(304, 116);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(53, 12);
            this.label34.TabIndex = 12;
            this.label34.Text = "鉴权IP：";
            // 
            // txt_authIp
            // 
            this.txt_authIp.Location = new System.Drawing.Point(358, 109);
            this.txt_authIp.Name = "txt_authIp";
            this.txt_authIp.Size = new System.Drawing.Size(80, 21);
            this.txt_authIp.TabIndex = 13;
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(158, 117);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(65, 12);
            this.label35.TabIndex = 10;
            this.label35.Text = "鉴权密码：";
            // 
            // txt_authPw5
            // 
            this.txt_authPw5.Location = new System.Drawing.Point(222, 111);
            this.txt_authPw5.Name = "txt_authPw5";
            this.txt_authPw5.Size = new System.Drawing.Size(73, 21);
            this.txt_authPw5.TabIndex = 11;
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Location = new System.Drawing.Point(8, 52);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(59, 12);
            this.label38.TabIndex = 4;
            this.label38.Text = "SIP号码：";
            // 
            // txt_SipNumber
            // 
            this.txt_SipNumber.Location = new System.Drawing.Point(72, 45);
            this.txt_SipNumber.Name = "txt_SipNumber";
            this.txt_SipNumber.Size = new System.Drawing.Size(78, 21);
            this.txt_SipNumber.TabIndex = 5;
            this.txt_SipNumber.Text = "100018695237";
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Location = new System.Drawing.Point(158, 52);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(65, 12);
            this.label39.TabIndex = 2;
            this.label39.Text = "是否联动：";
            // 
            // txt_gwIp
            // 
            this.txt_gwIp.Location = new System.Drawing.Point(236, 16);
            this.txt_gwIp.Name = "txt_gwIp";
            this.txt_gwIp.Size = new System.Drawing.Size(162, 21);
            this.txt_gwIp.TabIndex = 3;
            this.txt_gwIp.Text = "172.22.9.44";
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Location = new System.Drawing.Point(6, 24);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(65, 12);
            this.label40.TabIndex = 0;
            this.label40.Text = "操作者ID：";
            // 
            // txt_sipUser
            // 
            this.txt_sipUser.Location = new System.Drawing.Point(70, 18);
            this.txt_sipUser.Name = "txt_sipUser";
            this.txt_sipUser.Size = new System.Drawing.Size(80, 21);
            this.txt_sipUser.TabIndex = 1;
            this.txt_sipUser.Text = "12345";
            // 
            // tabPage4
            // 
            this.tabPage4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.tabPage4.Controls.Add(this.groupBox5);
            this.tabPage4.Location = new System.Drawing.Point(4, 22);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Size = new System.Drawing.Size(459, 376);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "通讯录管理";
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.groupBox2.Controls.Add(this.txt_Content);
            this.groupBox2.Controls.Add(this.label10);
            this.groupBox2.Controls.Add(this.txt_ResultInfo);
            this.groupBox2.Controls.Add(this.label11);
            this.groupBox2.Controls.Add(this.txt_ResultCode);
            this.groupBox2.Controls.Add(this.label12);
            this.groupBox2.Location = new System.Drawing.Point(476, 100);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(324, 370);
            this.groupBox2.TabIndex = 9;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "返回参数";
            // 
            // txt_Content
            // 
            this.txt_Content.Location = new System.Drawing.Point(72, 63);
            this.txt_Content.Name = "txt_Content";
            this.txt_Content.Size = new System.Drawing.Size(243, 21);
            this.txt_Content.TabIndex = 13;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(9, 68);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(65, 12);
            this.label10.TabIndex = 12;
            this.label10.Text = "返回内容：";
            // 
            // txt_ResultInfo
            // 
            this.txt_ResultInfo.Location = new System.Drawing.Point(11, 114);
            this.txt_ResultInfo.Name = "txt_ResultInfo";
            this.txt_ResultInfo.Size = new System.Drawing.Size(304, 248);
            this.txt_ResultInfo.TabIndex = 11;
            this.txt_ResultInfo.Text = "";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(9, 95);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(65, 12);
            this.label11.TabIndex = 10;
            this.label11.Text = "返回信息：";
            // 
            // txt_ResultCode
            // 
            this.txt_ResultCode.Location = new System.Drawing.Point(72, 32);
            this.txt_ResultCode.Name = "txt_ResultCode";
            this.txt_ResultCode.Size = new System.Drawing.Size(128, 21);
            this.txt_ResultCode.TabIndex = 9;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(9, 37);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(53, 12);
            this.label12.TabIndex = 8;
            this.label12.Text = "返回码：";
            // 
            // txt_log
            // 
            this.txt_log.BackColor = System.Drawing.Color.Silver;
            this.txt_log.Location = new System.Drawing.Point(3, 476);
            this.txt_log.Name = "txt_log";
            this.txt_log.Size = new System.Drawing.Size(796, 124);
            this.txt_log.TabIndex = 14;
            this.txt_log.Text = "";
            // 
            // txt_userAccount
            // 
            this.txt_userAccount.Location = new System.Drawing.Point(81, 34);
            this.txt_userAccount.Name = "txt_userAccount";
            this.txt_userAccount.Size = new System.Drawing.Size(85, 21);
            this.txt_userAccount.TabIndex = 7;
            this.txt_userAccount.Text = "123_user";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(242, 34);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(85, 21);
            this.textBox1.TabIndex = 9;
            this.textBox1.Text = "test123456";
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(81, 76);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(85, 21);
            this.textBox3.TabIndex = 11;
            this.textBox3.Text = "1";
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(242, 76);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(85, 21);
            this.textBox2.TabIndex = 13;
            this.textBox2.Text = "123456";
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(81, 120);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(85, 21);
            this.textBox5.TabIndex = 15;
            this.textBox5.Text = "6";
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(242, 120);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(85, 21);
            this.textBox4.TabIndex = 17;
            this.textBox4.Text = "1";
            // 
            // cbx_queryConditionType
            // 
            this.cbx_queryConditionType.FormattingEnabled = true;
            this.cbx_queryConditionType.Items.AddRange(new object[] {
            "0",
            "1",
            "3",
            "4"});
            this.cbx_queryConditionType.Location = new System.Drawing.Point(73, 220);
            this.cbx_queryConditionType.Name = "cbx_queryConditionType";
            this.cbx_queryConditionType.Size = new System.Drawing.Size(48, 20);
            this.cbx_queryConditionType.TabIndex = 48;
            this.cbx_queryConditionType.Text = "0";
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Location = new System.Drawing.Point(135, 224);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(77, 12);
            this.label42.TabIndex = 49;
            this.label42.Text = "查询条件值：";
            // 
            // btn_queryEmployee
            // 
            this.btn_queryEmployee.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btn_queryEmployee.Location = new System.Drawing.Point(260, 252);
            this.btn_queryEmployee.Name = "btn_queryEmployee";
            this.btn_queryEmployee.Size = new System.Drawing.Size(112, 43);
            this.btn_queryEmployee.TabIndex = 29;
            this.btn_queryEmployee.Text = "查询员工信息";
            this.btn_queryEmployee.UseVisualStyleBackColor = true;
            this.btn_queryEmployee.Click += new System.EventHandler(this.btn_queryEmployee_Click);
            // 
            // btn_queryEnterprise
            // 
            this.btn_queryEnterprise.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btn_queryEnterprise.Location = new System.Drawing.Point(62, 252);
            this.btn_queryEnterprise.Name = "btn_queryEnterprise";
            this.btn_queryEnterprise.Size = new System.Drawing.Size(132, 43);
            this.btn_queryEnterprise.TabIndex = 28;
            this.btn_queryEnterprise.Text = "查询企业通讯录";
            this.btn_queryEnterprise.UseVisualStyleBackColor = true;
            this.btn_queryEnterprise.Click += new System.EventHandler(this.btn_queryEnterprise_Click);
            // 
            // btn_QueryPersonInfo
            // 
            this.btn_QueryPersonInfo.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btn_QueryPersonInfo.Location = new System.Drawing.Point(260, 184);
            this.btn_QueryPersonInfo.Name = "btn_QueryPersonInfo";
            this.btn_QueryPersonInfo.Size = new System.Drawing.Size(112, 43);
            this.btn_QueryPersonInfo.TabIndex = 27;
            this.btn_QueryPersonInfo.Text = "查询个人详情";
            this.btn_QueryPersonInfo.UseVisualStyleBackColor = true;
            this.btn_QueryPersonInfo.Click += new System.EventHandler(this.btn_QueryPersonInfo_Click);
            // 
            // btn_QueryAddress
            // 
            this.btn_QueryAddress.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btn_QueryAddress.Location = new System.Drawing.Point(62, 184);
            this.btn_QueryAddress.Name = "btn_QueryAddress";
            this.btn_QueryAddress.Size = new System.Drawing.Size(132, 43);
            this.btn_QueryAddress.TabIndex = 26;
            this.btn_QueryAddress.Text = "查询个人通讯录";
            this.btn_QueryAddress.UseVisualStyleBackColor = true;
            this.btn_QueryAddress.Click += new System.EventHandler(this.btn_QueryAddress_Click);
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Location = new System.Drawing.Point(29, 31);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(89, 12);
            this.label43.TabIndex = 30;
            this.label43.Text = "操作者EC账号：";
            // 
            // txt_ECAccount
            // 
            this.txt_ECAccount.Location = new System.Drawing.Point(125, 26);
            this.txt_ECAccount.Name = "txt_ECAccount";
            this.txt_ECAccount.Size = new System.Drawing.Size(80, 21);
            this.txt_ECAccount.TabIndex = 31;
            this.txt_ECAccount.Text = "12345";
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.label48);
            this.groupBox5.Controls.Add(this.txt_departmentIDEx);
            this.groupBox5.Controls.Add(this.label47);
            this.groupBox5.Controls.Add(this.txt_beECAccount);
            this.groupBox5.Controls.Add(this.label45);
            this.groupBox5.Controls.Add(this.txt_pageNum);
            this.groupBox5.Controls.Add(this.label46);
            this.groupBox5.Controls.Add(this.txt_pageCount);
            this.groupBox5.Controls.Add(this.label44);
            this.groupBox5.Controls.Add(this.txt_queryCondition);
            this.groupBox5.Controls.Add(this.label43);
            this.groupBox5.Controls.Add(this.btn_queryEmployee);
            this.groupBox5.Controls.Add(this.txt_ECAccount);
            this.groupBox5.Controls.Add(this.btn_queryEnterprise);
            this.groupBox5.Controls.Add(this.btn_QueryAddress);
            this.groupBox5.Controls.Add(this.btn_QueryPersonInfo);
            this.groupBox5.Location = new System.Drawing.Point(2, 5);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(454, 363);
            this.groupBox5.TabIndex = 32;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "输入参数";
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Location = new System.Drawing.Point(29, 61);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(65, 12);
            this.label44.TabIndex = 32;
            this.label44.Text = "查询条件：";
            // 
            // txt_queryCondition
            // 
            this.txt_queryCondition.Location = new System.Drawing.Point(125, 58);
            this.txt_queryCondition.Name = "txt_queryCondition";
            this.txt_queryCondition.Size = new System.Drawing.Size(80, 21);
            this.txt_queryCondition.TabIndex = 33;
            this.txt_queryCondition.Text = "12345";
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Location = new System.Drawing.Point(254, 92);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(65, 12);
            this.label45.TabIndex = 36;
            this.label45.Text = "当前页数：";
            // 
            // txt_pageNum
            // 
            this.txt_pageNum.Location = new System.Drawing.Point(323, 88);
            this.txt_pageNum.Name = "txt_pageNum";
            this.txt_pageNum.Size = new System.Drawing.Size(83, 21);
            this.txt_pageNum.TabIndex = 37;
            this.txt_pageNum.Text = "1";
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Location = new System.Drawing.Point(29, 92);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(77, 12);
            this.label46.TabIndex = 34;
            this.label46.Text = "每页显示数：";
            // 
            // txt_pageCount
            // 
            this.txt_pageCount.Location = new System.Drawing.Point(125, 88);
            this.txt_pageCount.Name = "txt_pageCount";
            this.txt_pageCount.Size = new System.Drawing.Size(80, 21);
            this.txt_pageCount.TabIndex = 35;
            this.txt_pageCount.Text = "5";
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Location = new System.Drawing.Point(230, 61);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(89, 12);
            this.label47.TabIndex = 38;
            this.label47.Text = "被查者EC账号：";
            // 
            // txt_beECAccount
            // 
            this.txt_beECAccount.Location = new System.Drawing.Point(326, 56);
            this.txt_beECAccount.Name = "txt_beECAccount";
            this.txt_beECAccount.Size = new System.Drawing.Size(80, 21);
            this.txt_beECAccount.TabIndex = 39;
            this.txt_beECAccount.Text = "12345";
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Location = new System.Drawing.Point(28, 125);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(53, 12);
            this.label48.TabIndex = 40;
            this.label48.Text = "部门ID：";
            // 
            // txt_departmentIDEx
            // 
            this.txt_departmentIDEx.Location = new System.Drawing.Point(125, 122);
            this.txt_departmentIDEx.Name = "txt_departmentIDEx";
            this.txt_departmentIDEx.Size = new System.Drawing.Size(80, 21);
            this.txt_departmentIDEx.TabIndex = 41;
            this.txt_departmentIDEx.Text = "5";
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(803, 604);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.txt_log);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.txt_pw5);
            this.Controls.Add(this.txt_UserName);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txt_Uri);
            this.Controls.Add(this.label1);
            this.Name = "MainForm";
            this.Text = "通讯录同步";
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.tabPage4.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txt_pw5;
        private System.Windows.Forms.TextBox txt_UserName;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txt_Uri;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox txt_Content;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.RichTextBox txt_ResultInfo;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox txt_ResultCode;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox txt_dpPageNum;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txt_dpPageCount;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txt_departmentId;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txt_parentId;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txt_departmentName;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txt_Account;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.RichTextBox txt_log;
        private System.Windows.Forms.Button btn_queryDepartment;
        private System.Windows.Forms.Button btn_delDepartment;
        private System.Windows.Forms.Button btn_editDepartment;
        private System.Windows.Forms.Button btn_addDepartment;
        private System.Windows.Forms.TextBox txt_userAccount;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.ComboBox cbx_accountState;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.TextBox txt_dpId;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.TextBox txt_roleId;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox txt_levelId;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox txt_accountName;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox txt_loginPw5;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox txt_loginName;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox txt_AccountId;
        private System.Windows.Forms.Button btn_QueryAccount;
        private System.Windows.Forms.Button btn_delAccount;
        private System.Windows.Forms.Button btn_editAccount;
        private System.Windows.Forms.Button btn_AddAccount;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.TextBox txt_accountIdEx;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.TextBox txt_codition;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.TextBox txt_accountpageCount;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.TextBox txt_accountPageNum;
        private System.Windows.Forms.ComboBox cbx_accountType;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.ComboBox cbx_IsExact;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.ComboBox cbx_isExactQuery;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.ComboBox cbx_isJoint;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.TextBox txt_queryConditionValue;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.TextBox txt_sipPageNum;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.TextBox txt_sipPageCount;
        private System.Windows.Forms.Button btn_querySipNumber;
        private System.Windows.Forms.Button btn_delSipNumber;
        private System.Windows.Forms.Button btn_editSipNumber;
        private System.Windows.Forms.Button btn_addSipNumber;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.TextBox txt_authIp;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.TextBox txt_authPw5;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.TextBox txt_SipNumber;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.TextBox txt_gwIp;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.TextBox txt_sipUser;
        private System.Windows.Forms.ComboBox cbx_deviceType;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.ComboBox cbx_deleteSipUe;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.ComboBox cbx_authType;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.ComboBox cbx_addPrefix;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.ComboBox cbx_rightLevel;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.ComboBox cbx_queryConditionType;
        private System.Windows.Forms.Button btn_queryEmployee;
        private System.Windows.Forms.Button btn_queryEnterprise;
        private System.Windows.Forms.Button btn_QueryPersonInfo;
        private System.Windows.Forms.Button btn_QueryAddress;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.TextBox txt_departmentIDEx;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.TextBox txt_beECAccount;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.TextBox txt_pageNum;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.TextBox txt_pageCount;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.TextBox txt_queryCondition;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.TextBox txt_ECAccount;
    }
}


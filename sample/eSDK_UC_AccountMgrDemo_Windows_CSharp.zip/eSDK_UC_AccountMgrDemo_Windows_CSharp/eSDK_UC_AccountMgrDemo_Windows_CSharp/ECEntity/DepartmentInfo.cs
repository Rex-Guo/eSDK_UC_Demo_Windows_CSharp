﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace eSDK_UC_AccountMgrDemo_Windows_CSharp
{
    public class DepartmentInfo
    {
        public string userId { get; set; }

        public string parentId { get; set; }

        public string departmentId { get; set; }

        public string departmentName { get; set; }
    }
}

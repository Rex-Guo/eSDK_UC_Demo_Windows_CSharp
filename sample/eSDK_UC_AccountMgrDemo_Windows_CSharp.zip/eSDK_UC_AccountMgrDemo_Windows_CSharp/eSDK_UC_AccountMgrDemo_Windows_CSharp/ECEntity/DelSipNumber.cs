﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace eSDK_UC_AccountMgrDemo_Windows_CSharp
{
    public class DelSipNumber
    {
        public string userId { get; set; }

        public delSipNumber sip { get; set; }
    }
    public class delSipNumber
    {
        public string gwIp { get; set; }

        public string number { get; set; }

        public string deleteSipUe { get; set; }
    }
}

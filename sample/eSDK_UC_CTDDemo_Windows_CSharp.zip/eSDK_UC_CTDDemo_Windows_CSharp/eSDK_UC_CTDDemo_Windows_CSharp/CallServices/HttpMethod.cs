﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace eSDK_UC_CTDDemo_Windows_CSharp
{
    public enum HttpMethod
    {
        GET,
        PUT,
        POST,
        DELETE
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace eSDK_UC_CTDDemo_Windows_CSharp
{
    public class ECConstUri
    {
        //发送公告通知
        public static string affiche_uri = @"/esdk/rest/ec/appserver/affiche";

        //点击呼叫
        public static string ctd_uri = @"/esdk/rest/ec/appserver/ctd";
    }
}

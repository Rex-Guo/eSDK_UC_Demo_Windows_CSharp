﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace eSDK_UC_CTDDemo_Windows_CSharp
{
    public class CommentResponse
    {
        public string resultCode { get; set; }

        public string resultContext { get; set; }
    }
}
